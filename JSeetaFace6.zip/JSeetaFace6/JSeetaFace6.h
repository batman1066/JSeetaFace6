#ifndef JSEETAFACE6_H
#define JSEETAFACE6_H

#include "JSeetaFace6_global.h"

class JSEETAFACE6SHARED_EXPORT JSeetaFace6
{

public:
    JSeetaFace6();
};

#endif // JSEETAFACE6_H
